@extends('layout.layout')
@section('contenido')
    clientes
    @endsection